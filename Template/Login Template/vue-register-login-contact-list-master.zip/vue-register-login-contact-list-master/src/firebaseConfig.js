export default {
  apiKey: "AIzaSyA3x2WuF_m9E4zKYhInHVj1fsqToe-klEQ",
  authDomain: "webapp-6bf36.firebaseapp.com",
  databaseURL: "https://webapp-6bf36.firebaseio.com",
  projectId: "webapp-6bf36",
  storageBucket: "webapp-6bf36.appspot.com",
  messagingSenderId: "781463977800"
}
