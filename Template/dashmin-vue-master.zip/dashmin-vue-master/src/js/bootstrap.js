window.$ = window.jQuery = require('jquery');
require('popper.js');
require('bootstrap');
window.List = require('list.js');
window.swal = require('sweetalert');
require('select2');
window.toastr = require('toastr');
window.NProgress = require('nprogress');
require('./scripts');
