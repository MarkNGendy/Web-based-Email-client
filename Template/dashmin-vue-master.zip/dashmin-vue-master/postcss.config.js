module.exports = {
	plugins: {
		'autoprefixer': {}
	}
}